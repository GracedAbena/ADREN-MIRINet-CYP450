import numpy as np
from sklearn.metrics import roc_auc_score, matthews_corrcoef, f1_score, precision_score, recall_score, confusion_matrix

def compute_multitask_metrics(y_true: np.ndarray, y_prob: np.ndarray, thr: float = 0.5):
    K = y_true.shape[1]
    y_pred = (y_prob >= thr).astype(int)
    per = []

    for k in range(K):
        yt, yp, pr = y_true[:, k], y_pred[:, k], y_prob[:, k]
        auc = roc_auc_score(yt, pr) if len(np.unique(yt)) > 1 else np.nan
        mcc = matthews_corrcoef(yt, yp) if len(np.unique(yt)) > 1 else np.nan
        f1  = f1_score(yt, yp, zero_division=0)
        pre = precision_score(yt, yp, zero_division=0)
        sen = recall_score(yt, yp, zero_division=0)

        tn, fp, fn, tp = confusion_matrix(yt, yp, labels=[0,1]).ravel()
        spe = tn / (tn + fp + 1e-12)
        acc = (tp + tn) / (tp + tn + fp + fn + 1e-12)

        per.append({
            "Acc": acc*100, "AUC": auc*100, "Sen": sen*100, "Spe": spe*100,
            "MCC": mcc*100, "F1": f1*100, "Pre": pre*100
        })

    macro = {k: float(np.nanmean([d[k] for d in per])) for k in per[0].keys()}
    return per, macro
