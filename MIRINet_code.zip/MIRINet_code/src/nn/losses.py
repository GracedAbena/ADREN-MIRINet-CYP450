import torch
import torch.nn as nn

class MultiTaskBCEWithLogits(nn.Module):
    def __init__(self):
        super().__init__()
        self.crit = nn.BCEWithLogitsLoss()

    def forward(self, logits, targets):
        return self.crit(logits, targets)
