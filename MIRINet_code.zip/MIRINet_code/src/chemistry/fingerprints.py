import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem, MACCSkeys
from rdkit.Chem.rdMolDescriptors import GetErGFingerprint

def smiles_to_mol(smiles: str):
    mol = Chem.MolFromSmiles(smiles)
    return mol

def _bitvect_to_np(bv) -> np.ndarray:
    arr = np.zeros((bv.GetNumBits(),), dtype=np.float32)
    from rdkit.DataStructs import ConvertToNumpyArray
    ConvertToNumpyArray(bv, arr)
    return arr

def maccs_fp(mol) -> np.ndarray:
    bv = MACCSkeys.GenMACCSKeys(mol)  # 167 bits
    return _bitvect_to_np(bv)

def erg_fp(mol) -> np.ndarray:
    sv = GetErGFingerprint(mol)       # sparse counts; length ~315
    L = sv.GetLength()
    dense = np.zeros((L,), dtype=np.float32)
    for idx, val in sv.GetNonzeroElements().items():
        dense[idx] = float(val)
    return np.log1p(dense).astype(np.float32)

def pubchem_proxy_fp(mol, n_bits: int = 1024, radius: int = 2) -> np.ndarray:
    # Proxy fingerprint: Morgan/ECFP (common substitute for PubChem FP in many pipelines)
    bv = AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=n_bits)
    return _bitvect_to_np(bv)

def build_fingerprints(smiles: str):
    mol = smiles_to_mol(smiles)
    if mol is None:
        return None
    return {
        "maccs": maccs_fp(mol),
        "erg": erg_fp(mol),
        "pub": pubchem_proxy_fp(mol, n_bits=1024, radius=2),
    }
