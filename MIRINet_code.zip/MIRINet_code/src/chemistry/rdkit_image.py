from rdkit import Chem
from rdkit.Chem import Draw
from PIL import Image
import numpy as np

def smiles_to_image(smiles: str, size: int = 224) -> Image.Image:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return Image.fromarray(np.zeros((size, size, 3), dtype=np.uint8))
    img = Draw.MolToImage(mol, size=(size, size), kekulize=True)
    if img.mode != "RGB":
        img = img.convert("RGB")
    return img
