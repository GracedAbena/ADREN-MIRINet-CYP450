import torch
import numpy as np
from tqdm import tqdm

from ..nn.losses import MultiTaskBCEWithLogits
from ..nn.metrics import compute_multitask_metrics
from ..utils.checkpoint import save_checkpoint

class Trainer:
    def __init__(self, model, device, lr=3e-4, weight_decay=1e-4,
                 reg_lambda=1.0):
        self.model = model.to(device)
        self.device = device
        self.reg_lambda = reg_lambda
        self.loss_fn = MultiTaskBCEWithLogits()
        self.opt = torch.optim.AdamW(self.model.parameters(), lr=lr, weight_decay=weight_decay)

    def _forward_batch(self, batch, model_type: str):
        y = batch["y"].to(self.device)
        if model_type == "adren":
            logits, reg = self.model(
                batch["fp_maccs"].to(self.device),
                batch["fp_erg"].to(self.device),
                batch["fp_pub"].to(self.device),
            )
        else:
            logits, reg = self.model(batch["image"].to(self.device))
        loss = self.loss_fn(logits, y) + self.reg_lambda * reg
        return loss, logits, y

    @torch.no_grad()
    def evaluate(self, loader, model_type: str, thr: float = 0.5):
        self.model.eval()
        ys, ps = [], []
        for batch in loader:
            _, logits, y = self._forward_batch(batch, model_type)
            prob = torch.sigmoid(logits).cpu().numpy()
            ys.append(y.cpu().numpy())
            ps.append(prob)
        y_true = np.concatenate(ys, 0)
        y_prob = np.concatenate(ps, 0)
        per, macro = compute_multitask_metrics(y_true, y_prob, thr=thr)
        return per, macro

    def fit(self, train_loader, val_loader, epochs: int,
            model_type: str, save_path: str, thr: float = 0.5):
        best_auc = -1.0
        for ep in range(1, epochs+1):
            self.model.train()
            pbar = tqdm(train_loader, desc=f"Epoch {ep}/{epochs}")
            for batch in pbar:
                self.opt.zero_grad()
                loss, _, _ = self._forward_batch(batch, model_type)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.opt.step()
                pbar.set_postfix(loss=float(loss.item()))

            _, macro = self.evaluate(val_loader, model_type, thr=thr)
            val_auc = macro["AUC"]
            val_mcc = macro["MCC"]
            print(f"[Epoch {ep}] Val AUC={val_auc:.2f}  Val MCC={val_mcc:.2f}")

            if val_auc > best_auc:
                best_auc = val_auc
                save_checkpoint(self.model.state_dict(), save_path)
                print(f"Saved best model -> {save_path}")

        return best_auc
