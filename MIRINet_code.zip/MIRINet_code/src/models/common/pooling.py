
import torch

def mean_pool_tokens(x: torch.Tensor):
    # x: [B,T,D]
    return x.mean(dim=1)
