import torch
import torch.nn as nn

from ...constants import NUM_TASKS
from ..common.pooling import mean_pool_tokens
from ..common.mlp_head import MLPHead
from .embedding import GroupWiseLinearEmbedding
from .blocks import ADRENBlock

class ADREN(nn.Module):
    """
    ADREN: Attention Driven Descriptor Residual Encoder Network
    Inputs: MACCS(167), ErG(315), PubChem-proxy(1024)
    Output: logits [B,5]
    """
    def __init__(self, d_model=192, num_heads=6, depth=4,
                 groups_maccs=7, groups_erg=9, groups_pub=16,
                 dropout=0.1, tau=1.0, reg_weight=0.1):
        super().__init__()
        self.emb_maccs = GroupWiseLinearEmbedding(167,  groups_maccs, d_model)
        self.emb_erg   = GroupWiseLinearEmbedding(315,  groups_erg,   d_model)
        self.emb_pub   = GroupWiseLinearEmbedding(1024, groups_pub,   d_model)

        T = groups_maccs + groups_erg + groups_pub
        self.pos = nn.Parameter(torch.zeros(1, T, d_model))
        self.type_emb = nn.Embedding(3, d_model)

        self.blocks = nn.ModuleList([
            ADRENBlock(d_model, num_heads, dropout=dropout, tau=tau, reg_weight=reg_weight)
            for _ in range(depth)
        ])
        self.ln = nn.LayerNorm(d_model)
        self.head = MLPHead(d_model, d_model, NUM_TASKS, dropout=dropout)

    def forward(self, fp_maccs, fp_erg, fp_pub):
        t1 = self.emb_maccs(fp_maccs)
        t2 = self.emb_erg(fp_erg)
        t3 = self.emb_pub(fp_pub)

        B = fp_maccs.size(0)
        t1 = t1 + self.type_emb(torch.zeros((B, t1.size(1)), device=t1.device, dtype=torch.long))
        t2 = t2 + self.type_emb(torch.ones((B, t2.size(1)), device=t2.device, dtype=torch.long))
        t3 = t3 + self.type_emb(2*torch.ones((B, t3.size(1)), device=t3.device, dtype=torch.long))

        x = torch.cat([t1, t2, t3], dim=1)
        x = x + self.pos[:, :x.size(1), :]

        reg_total = 0.0
        for blk in self.blocks:
            x, reg = blk(x)
            reg_total = reg_total + reg

        x = self.ln(x)
        pooled = mean_pool_tokens(x)
        logits = self.head(pooled)
        return logits, reg_total
