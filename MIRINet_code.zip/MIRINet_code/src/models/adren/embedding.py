import torch
import torch.nn as nn

class GroupWiseLinearEmbedding(nn.Module):
    """
    Split a fingerprint vector into G groups -> G tokens -> linear projection to d_model
    """
    def __init__(self, in_dim: int, groups: int, d_model: int):
        super().__init__()
        assert in_dim % groups == 0, f"in_dim {in_dim} must be divisible by groups {groups}"
        self.groups = groups
        self.group_dim = in_dim // groups
        self.proj = nn.Linear(self.group_dim, d_model)

    def forward(self, x: torch.Tensor):
        # x: [B,in_dim] -> [B,G,d_model]
        B = x.size(0)
        xg = x.view(B, self.groups, self.group_dim)
        return self.proj(xg)
