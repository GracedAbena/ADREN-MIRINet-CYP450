import torch
import torch.nn as nn
import torch.nn.functional as F

def tanimoto_sim(x: torch.Tensor, eps: float = 1e-8):
    # x: [B,T,D], non-negative
    dot = torch.einsum("btd,bsd->bts", x, x)
    xx  = torch.einsum("btd,btd->bt", x, x)
    denom = xx.unsqueeze(-1) + xx.unsqueeze(-2) - dot
    return dot / (denom + eps)

class TRMHA(nn.Module):
    """
    TR-MHA: Tanimoto-regularized multi-head attention.
    Returns (out, reg_loss).
    """
    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.1,
                 tau: float = 1.0, reg_weight: float = 0.1):
        super().__init__()
        assert d_model % num_heads == 0
        self.h = num_heads
        self.dk = d_model // num_heads
        self.tau = tau
        self.reg_weight = reg_weight

        self.qkv = nn.Linear(d_model, 3*d_model)
        self.out = nn.Linear(d_model, d_model)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor):
        B, T, D = x.shape
        qkv = self.qkv(x).view(B, T, 3, self.h, self.dk).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]         # [B,H,T,dk]

        logits = (q @ k.transpose(-2, -1)) / (self.dk ** 0.5)  # [B,H,T,T]

        x_pos = F.relu(x)
        sim = tanimoto_sim(x_pos).unsqueeze(1)  # [B,1,T,T]
        logits = logits + (sim / self.tau)

        attn = torch.softmax(logits, dim=-1)
        attn = self.drop(attn)

        y = (attn @ v).transpose(1, 2).contiguous().view(B, T, D)
        y = self.out(y)

        # alignment reg: encourage attention to match similarity pattern
        attn_mean = attn.mean(dim=1)   # [B,T,T]
        reg = 1.0 - F.cosine_similarity(attn_mean.reshape(B, -1), sim.squeeze(1).reshape(B, -1), dim=-1).mean()
        return y, self.reg_weight * reg
