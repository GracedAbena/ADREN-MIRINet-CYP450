import torch
import torch.nn as nn

from .attention_trmha import TRMHA

class ADRENBlock(nn.Module):
    def __init__(self, d_model: int, num_heads: int,
                 mlp_ratio: float = 4.0, dropout: float = 0.1,
                 tau: float = 1.0, reg_weight: float = 0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = TRMHA(d_model, num_heads, dropout=dropout, tau=tau, reg_weight=reg_weight)
        self.ln2 = nn.LayerNorm(d_model)

        hidden = int(d_model * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(d_model, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor):
        y, reg = self.attn(self.ln1(x))
        x = x + y
        x = x + self.mlp(self.ln2(x))
        return x, reg
