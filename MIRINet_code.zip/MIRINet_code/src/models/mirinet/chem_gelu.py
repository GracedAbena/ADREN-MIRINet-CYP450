import torch
import torch.nn as nn
import torch.nn.functional as F

class ChemGELU(nn.Module):
    """
    Chem-GELU: GELU gated by sigmoid(alpha*x) for stable chemical edge sensitivity.
    """
    def __init__(self, alpha: float = 0.5):
        super().__init__()
        self.alpha = nn.Parameter(torch.tensor(alpha, dtype=torch.float32))

    def forward(self, x: torch.Tensor):
        return F.gelu(x) * torch.sigmoid(self.alpha * x)
