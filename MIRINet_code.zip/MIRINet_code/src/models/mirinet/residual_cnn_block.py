import torch
import torch.nn as nn

from .chem_gelu import ChemGELU
from .se import SEModule

class ResidualCNNBlock(nn.Module):
    """
    Conv-BN-ChemGELU -> Conv-BN -> SE -> Skip -> ChemGELU
    """
    def __init__(self, in_ch: int, out_ch: int, stride: int = 1, se_reduction: int = 16):
        super().__init__()
        self.conv1 = nn.Conv2d(in_ch, out_ch, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_ch)
        self.act = ChemGELU(alpha=0.5)

        self.conv2 = nn.Conv2d(out_ch, out_ch, 3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_ch)

        self.se = SEModule(out_ch, reduction=se_reduction)

        self.skip = None
        if stride != 1 or in_ch != out_ch:
            self.skip = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_ch),
            )

    def forward(self, x: torch.Tensor):
        identity = x
        y = self.act(self.bn1(self.conv1(x)))
        y = self.bn2(self.conv2(y))
        y = self.se(y)
        if self.skip is not None:
            identity = self.skip(identity)
        return self.act(y + identity)
