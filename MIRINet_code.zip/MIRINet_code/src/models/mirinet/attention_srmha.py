import torch
import torch.nn as nn
import torch.nn.functional as F

class SRMHA(nn.Module):
    """
    SR-MHA: Structure-regularized multi-head attention.
    Regularizer encourages attention smoothness over a kNN token graph.
    """
    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.1,
                 reg_weight: float = 0.05, k_nn: int = 8):
        super().__init__()
        assert d_model % num_heads == 0
        self.h = num_heads
        self.dk = d_model // num_heads
        self.reg_weight = reg_weight
        self.k_nn = k_nn

        self.qkv = nn.Linear(d_model, 3*d_model)
        self.out = nn.Linear(d_model, d_model)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor):
        B, T, D = x.shape
        qkv = self.qkv(x).view(B, T, 3, self.h, self.dk).permute(2,0,3,1,4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        logits = (q @ k.transpose(-2,-1)) / (self.dk ** 0.5)
        attn = torch.softmax(logits, dim=-1)
        attn = self.drop(attn)

        y = (attn @ v).transpose(1,2).contiguous().view(B,T,D)
        y = self.out(y)

        # kNN graph from cosine similarity
        x_norm = F.normalize(x, dim=-1)
        sim = x_norm @ x_norm.transpose(-2,-1)     # [B,T,T]
        _, idx = torch.topk(sim, k=min(self.k_nn+1, T), dim=-1)  # includes self

        A = torch.zeros_like(sim)
        A.scatter_(-1, idx, 1.0)

        eye = torch.eye(T, device=x.device).unsqueeze(0)
        A = A * (1.0 - eye)

        attn_mean = attn.mean(dim=1)               # [B,T,T]
        diff = attn_mean.unsqueeze(2) - attn_mean.unsqueeze(1)  # [B,T,T,T]
        smooth = (A.unsqueeze(-1) * (diff**2).sum(dim=-1)).mean()
        reg_loss = self.reg_weight * smooth

        return y, reg_loss
