import torch
import torch.nn as nn

from ...constants import NUM_TASKS
from ..common.pooling import mean_pool_tokens
from ..common.mlp_head import MLPHead
from .chem_gelu import ChemGELU
from .residual_cnn_block import ResidualCNNBlock
from .attention_srmha import SRMHA

class MIRINet(nn.Module):
    """
    MIRINet: Molecular Image Residual Inhibition Network
    Input: RDKit 2D compound image
    Output: logits [B,5]
    """
    def __init__(self, base_ch=64, d_model=256, num_heads=8, attn_depth=2,
                 dropout=0.1, reg_weight=0.05):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(3, base_ch, 7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(base_ch),
            ChemGELU(alpha=0.5),
            nn.MaxPool2d(3, stride=2, padding=1),
        )

        self.stage1 = nn.Sequential(
            ResidualCNNBlock(base_ch, base_ch, stride=1),
            ResidualCNNBlock(base_ch, base_ch, stride=1),
        )
        self.stage2 = nn.Sequential(
            ResidualCNNBlock(base_ch, base_ch*2, stride=2),
            ResidualCNNBlock(base_ch*2, base_ch*2, stride=1),
        )
        self.stage3 = nn.Sequential(
            ResidualCNNBlock(base_ch*2, base_ch*4, stride=2),
            ResidualCNNBlock(base_ch*4, base_ch*4, stride=1),
        )

        self.to_tokens = nn.Conv2d(base_ch*4, d_model, 1)
        self.ln = nn.LayerNorm(d_model)

        self.attn_blocks = nn.ModuleList([
            nn.ModuleDict({
                "ln": nn.LayerNorm(d_model),
                "attn": SRMHA(d_model, num_heads, dropout=dropout, reg_weight=reg_weight),
                "ffn": nn.Sequential(
                    nn.Linear(d_model, d_model*4),
                    nn.GELU(),
                    nn.Dropout(dropout),
                    nn.Linear(d_model*4, d_model),
                    nn.Dropout(dropout),
                )
            })
            for _ in range(attn_depth)
        ])

        self.head = MLPHead(d_model, d_model, NUM_TASKS, dropout=dropout)

    def forward(self, image: torch.Tensor):
        x = self.stem(image)
        x = self.stage1(x)
        x = self.stage2(x)
        x = self.stage3(x)

        x = self.to_tokens(x)               # [B,d,H,W]
        B, D, H, W = x.shape
        tokens = x.flatten(2).transpose(1,2)  # [B,T,D]
        tokens = self.ln(tokens)

        reg_total = 0.0
        for blk in self.attn_blocks:
            y, reg = blk["attn"](blk["ln"](tokens))
            tokens = tokens + y
            tokens = tokens + blk["ffn"](tokens)
            reg_total += reg

        pooled = mean_pool_tokens(tokens)
        logits = self.head(pooled)
        return logits, reg_total
