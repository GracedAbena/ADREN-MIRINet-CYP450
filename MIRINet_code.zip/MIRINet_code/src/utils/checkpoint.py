import torch
from pathlib import Path

def save_checkpoint(state_dict, path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save(state_dict, path)

def load_checkpoint(model, path: str, device="cpu"):
    sd = torch.load(path, map_location=device)
    model.load_state_dict(sd)
    return model
