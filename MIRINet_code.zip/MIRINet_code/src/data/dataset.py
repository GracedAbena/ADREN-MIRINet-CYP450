import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision import transforms

from ..constants import ISOFORMS
from ..chemistry.rdkit_image import smiles_to_image
from ..chemistry.fingerprints import build_fingerprints

class CYPDataset(Dataset):
    """
    CSV columns:
      smiles, CYP1A2, CYP2C9, CYP2C19, CYP2D6, CYP3A4
    """
    def __init__(self, csv_path: str, mode: str,
                 use_images: bool, use_fps: bool,
                 image_size: int = 224):
        self.df = pd.read_csv(csv_path)
        self.mode = mode
        self.use_images = use_images
        self.use_fps = use_fps
        self.image_size = image_size

        self.tf = transforms.Compose([transforms.ToTensor()])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i: int):
        row = self.df.iloc[i]
        smiles = str(row["smiles"])

        y = torch.tensor([float(row[c]) for c in ISOFORMS], dtype=torch.float32)
        out = {"smiles": smiles, "y": y}

        if self.use_images:
            img = smiles_to_image(smiles, size=self.image_size)
            out["image"] = self.tf(img)

        if self.use_fps:
            fps = build_fingerprints(smiles)
            if fps is None:
                fps = {
                    "maccs": np.zeros((167,), dtype=np.float32),
                    "erg": np.zeros((315,), dtype=np.float32),
                    "pub": np.zeros((1024,), dtype=np.float32),
                }
            out["fp_maccs"] = torch.tensor(fps["maccs"], dtype=torch.float32)
            out["fp_erg"]   = torch.tensor(fps["erg"], dtype=torch.float32)
            out["fp_pub"]   = torch.tensor(fps["pub"], dtype=torch.float32)

        return out
