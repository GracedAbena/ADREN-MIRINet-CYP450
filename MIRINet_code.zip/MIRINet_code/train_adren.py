import argparse
import yaml
import torch
from torch.utils.data import DataLoader

from src.utils.seed import seed_everything
from src.data.dataset import CYPDataset
from src.models.adren.model import ADREN
from src.training.trainer import Trainer

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=str, default="configs/adren.yaml")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config, "r"))
    seed_everything(cfg.get("seed", 42))

    device = "cuda" if torch.cuda.is_available() else "cpu"

    train_ds = CYPDataset(cfg["train_csv"], "train", use_images=False, use_fps=True)
    val_ds   = CYPDataset(cfg["val_csv"], "val",   use_images=False, use_fps=True)

    train_ld = DataLoader(train_ds, batch_size=cfg["batch_size"], shuffle=True, num_workers=2)
    val_ld   = DataLoader(val_ds,   batch_size=cfg["batch_size"], shuffle=False, num_workers=2)

    model = ADREN(**cfg["model"])
    trainer = Trainer(model, device, lr=cfg["lr"], weight_decay=cfg["weight_decay"], reg_lambda=cfg["reg_lambda"])

    trainer.fit(train_ld, val_ld, epochs=cfg["epochs"], model_type="adren", save_path=cfg["save_path"], thr=cfg["thr"])

if __name__ == "__main__":
    main()
